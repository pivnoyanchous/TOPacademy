using AnimeSite.Models;
using Microsoft.EntityFrameworkCore;

namespace AnimeSite.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<AnimeCharacter> AnimeCharacters => Set<AnimeCharacter>();
    public DbSet<AnimeCategory> AnimeCategories => Set<AnimeCategory>();
}
