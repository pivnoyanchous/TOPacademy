namespace AnimeSite.Models;

public class AnimeCategory
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public List<AnimeCharacter> Characters { get; set; } = new();
}
