namespace AnimeSite.Models;

public class AnimeCharacter
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int Power { get; set; }

    public int AnimeCategoryId { get; set; }
    public AnimeCategory? AnimeCategory { get; set; }
}
