using AnimeSite.Data;
using AnimeSite.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseInMemoryDatabase("AnimeDb"));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    if (!context.AnimeCategories.Any())
    {
        var category1 = new AnimeCategory { Name = "Наруто" };
        var category2 = new AnimeCategory { Name = "Магическая битва" };

        context.AnimeCategories.AddRange(category1, category2);
        context.SaveChanges();

        context.AnimeCharacters.AddRange(
            new AnimeCharacter { Name = "Наруто Узумаки", Power = 95, AnimeCategoryId = category1.Id },
            new AnimeCharacter { Name = "Саске Учиха", Power = 98, AnimeCategoryId = category1.Id },
            new AnimeCharacter { Name = "Сатору Годжо", Power = 100, AnimeCategoryId = category2.Id }
        );

        context.SaveChanges();
    }
}

app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
